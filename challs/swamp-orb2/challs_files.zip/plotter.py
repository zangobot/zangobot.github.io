import pickle
import numpy as np
import scipy.io
import matplotlib.pyplot as plt
from PIL import Image

def predict_impact_point(row):
    x,y = row[0],row[1]
    v = row[2]
    theta = row[3]
    gamma = row[4]
    vx = v * np.cos(theta)*np.cos(gamma)
    vy = v * np.cos(theta)*np.sin(gamma)
    vz = v * np.sin(theta)
    g = 9.81
    t = 2*vz / g
    return x - vx*t, y - vy*t

data = pickle.load(open('page_of_numbers.p','rb'))
matrix_data = [ ]
res = []
for d in data:
    val =predict_impact_point([i for i in d])
    matrix_data.append(val)
matrix_data = np.array(matrix_data)

plt.plot(matrix_data[:,0], matrix_data[:,1],'o')
plt.show()
